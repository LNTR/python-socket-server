<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
  <form action="./sum.php" method="POST">
    <input type="text" name ="a">
    <input type="text" name ="b">

  <button>Submit</button>
  </form>
  
<img src="./foo.jpg" alt="" srcset="">
  
</body>
</html>

